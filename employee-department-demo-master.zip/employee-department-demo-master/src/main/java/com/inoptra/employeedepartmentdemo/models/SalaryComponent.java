package com.inoptra.employeedepartmentdemo.models;

import org.springframework.stereotype.Repository;

import javax.persistence.*;

/* @Author: Shrikrishna Prabhumirashi
 * @Description:
 * SalaryComponent is dependent upon base salary and can be calculated as baseSalary multiplied by respective factor.
 *  i.e. SalaryComponent_amount = baseSalary * factor;
 *  Actual salary can be calculated as sum of all SalaryComponent amounts.
 * */
@Entity
@Table(name = "SALARY_COMPONENT")
public class SalaryComponent {

	@javax.persistence.Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private long Id;

    @Column(name = "NAME")
    private String name;

    @Column(name = "FACTOR")
    private double factor;

    @Column(name = "SALARY_ID")
    private int salaryId;


	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getFactor() {
        return factor;
    }

    public void setFactor(double factor) {
        this.factor = factor;
    }
}
