package com.inoptra.employeedepartmentdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.CrossOrigin;

@SpringBootApplication
@CrossOrigin
public class EmployeeDepartmentDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeDepartmentDemoApplication.class, args);
	}

}
