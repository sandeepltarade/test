package com.inoptra.employeedepartmentdemo.models;

import org.springframework.stereotype.Repository;

import javax.persistence.*;
import java.util.List;

/* @Author: Shrikrishna Prabhumirashi
 * @Description:
 * SalaryComponent is dependent upon base salary and can be calculated as baseSalary multiplied by respective factor.
 *  i.e. SalaryComponent_amount = baseSalary * factor;
 *  Actual salary can be calculated as sum of all SalaryComponent amounts.
 * */
@Entity
@Table(name = "SALARY")
public class Salary {

	@javax.persistence.Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private long Id;

	@Column(name = "BASE_SALARY")
	private double baseSalary;

	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="SALARY_ID")
	private List<SalaryComponent> salaryComonents;

	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}
	public double getBaseSalary() {
		return baseSalary;
	}
	public void setBaseSalary(double baseSalary) {
		this.baseSalary = baseSalary;
	}
	public List<SalaryComponent> getSalaryComonents() {
		return salaryComonents;
	}
	public void setSalaryComonents(List<SalaryComponent> salaryComonents) {
		this.salaryComonents = salaryComonents;
	}
	
}
