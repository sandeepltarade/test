package com.inoptra.employeedepartmentdemo.services;

import com.inoptra.employeedepartmentdemo.models.Department;
import com.inoptra.employeedepartmentdemo.repositories.DepartmentRepository;
import com.inoptra.employeedepartmentdemo.repositories.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * @Author: Shrikrishna Prabhumirashi
 * @Description:
 * Service layer contract which supports operations on Department object
 **/
@Service
public class DepartmentService {

    @Autowired
    private DepartmentRepository departmentRepository;

    public Department getDepartmentById(long deptId) {
        Optional<Department> departmentOptional = departmentRepository.findById(deptId);
        return departmentOptional.get();
    }

    public List<Department> getAllDepartments() {
        List<Department> departmentList = departmentRepository.findAll();
        return departmentList;
    }
}
